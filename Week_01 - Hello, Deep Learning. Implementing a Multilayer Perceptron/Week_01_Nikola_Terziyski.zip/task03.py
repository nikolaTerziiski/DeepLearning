import numpy as np

def show_numpy_array():
    np.array([True, 1, 2]) + np.array([3, 4, False])
    
    print("Answer B")
    
if __name__ == '__main__':
    show_numpy_array()