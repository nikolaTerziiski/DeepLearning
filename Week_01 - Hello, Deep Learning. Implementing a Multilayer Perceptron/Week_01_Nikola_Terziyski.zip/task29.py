import numpy as np


def create_dataset(n):

    list = []
    for i in range(n):
        list.append((i, i * 2))

    return list


def initialize_weights(start, finish):
    return np.random.uniform(start, finish)


if __name__ == '__main__':
    print(create_dataset(4))
    print(initialize_weights(0, 100))
    print(initialize_weights(0, 10))
